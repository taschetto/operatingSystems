Alunos: Rodrigo Dias Correa e Guilherme Taschetto

Para compilar:

	make

Para executar:

	./main

Funções do shell:

	init
	load
	ls <path>
	mkdir <path>
	rmdir <path>
	create <path/file>
	rm <path/file>
	write <content> <path/file>
	cat <path/file>
